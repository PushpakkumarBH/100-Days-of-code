const express = require('express');
const https = require('https');

const app = express()
const url = "https://api.openweathermap.org/data/2.5/weather?q=paris&appid=5b609a10b1caed5ad07c7807692ed0ad"
https.get(url,function(response){
    console.log(response.statusCode);

    response.on("data",function(data){
        const weatherData = JSON.parse(data);
        const temp = weatherData.main.temp;
        const desc = weatherData.weather[0].description
        console.log(temp);
        console.log("Today weather has",desc)

    })

})

app.get("/",function(req,res){
    res.send("Server is up and running sucessfully");
    res.send(weatherData);
})

app.listen(3000,function(){
    console.log("Server is running at port 3000.");
})